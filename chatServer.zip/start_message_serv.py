from wchatServer import WChatServer
import threading, os
from wsqluse import WSQLshell
import wsettings as s
import wchat_config as wc

sqlshell = WSQLshell(s.db_name, s.db_user, s.db_pass, s.db_location)
tcpServer = WChatServer(port=wc.port, ip=wc.ip,sqlshell=sqlshell)

try:
	threading.Thread(target=tcpServer.tcpLoggingServ, args=()).start()
except KeyboardInterrupt:
	os._exit()
